module Main where

import Graphics.Gloss
import Graphics.Gloss.Interface.IO.Game  -- Используйте этот модуль вместо Pure.Game

main :: IO ()
main = display (InWindow "Test" (800, 600) (0, 0)) white (Circle 50)